# Sound Effects

Folder ini berisi file audio yang dibutuhkan untuk game:

- `30second.mp3` - Timer 30 detik di halaman game setelah soal keluar
- `correct.mp3` - Suara untuk jawaban benar di halaman game
- `incorrect.mp3` - Suara untuk jawaban salah di halaman game
- `klik.mp3` - Suara untuk setiap klik (menu, dadu, leaderboard, aturan, mulai)
- `dice.mp3` - Suara dadu di halaman game saat klik dadu

**Catatan:** File audio ini perlu ditambahkan secara manual ke folder ini.

